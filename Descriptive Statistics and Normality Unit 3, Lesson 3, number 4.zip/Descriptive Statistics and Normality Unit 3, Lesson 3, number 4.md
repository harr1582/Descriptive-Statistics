

```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
norm = np.random.normal (29, 12, 100) 
plt.hist(norm, bins = 20, color = 'purple')
plt.axvline(norm.mean(), color ='b', linestyle = 'solid', linewidth = 2)
plt.axvline(norm.mean() + norm.std(), color ='black', linestyle = 'dashed', linewidth = '1')
plt.axvline(norm.mean() - norm.std(), color ='black', linestyle = 'dashed', linewidth = '1')
plt.title("Normal Distribution")
plt.show()
```


![png](output_1_0.png)



```python
poisson = np.random.poisson(17, 100)
plt.hist(poisson, bins = 20, color= 'orange')
plt.axvline(poisson.mean(), color ='b', linestyle = 'solid', linewidth = 2)
plt.axvline(poisson.mean() + poisson.std(), color ='black', linestyle = 'dashed', linewidth = '1')
plt.axvline(poisson.mean() - poisson.std(), color ='black', linestyle = 'dashed', linewidth = '1')
plt.title("Poisson Distribution")
plt.show()
```


![png](output_2_0.png)



```python
gamma = np.random.gamma(29, 1, 100)
plt.hist(gamma, bins = 20, color = 'blue')
plt.axvline(gamma.mean(), linestyle = 'solid', color = 'black', linewidth = 2)
plt.axvline(gamma.mean() + gamma.std(), linestyle = 'dashed', color = 'orange', linewidth = 1)
plt.axvline(gamma.mean() - gamma.std(), linestyle = 'dashed', color = 'orange', linewidth = 1)
plt.title('Gamma Distribution')
plt.show()
```


![png](output_3_0.png)



```python
bernouli = np.random.binomial (5, .05, 100)
plt.hist(bernouli, bins = 20, color = 'cyan')
plt.title('Bernouli/Binomial Distribution')
plt.axvline(bernouli.mean(), linestyle = 'solid', linewidth = 2, color = 'purple')
plt.axvline(bernouli.mean() + bernouli.std(), linestyle = 'dashed', linewidth = 2, color = 'black')
plt.axvline(bernouli.mean() - bernouli.std(), linestyle = 'dashed', linewidth = 2, color = 'black')
plt.show()
```


![png](output_4_0.png)



```python
chisquare = np.random.chisquare(25, 100)
plt.hist(chisquare, bins = 20, color = 'red')
plt.title('ChiSquare Distribution')
plt.axvline(chisquare.mean(), linestyle = 'solid', linewidth = 2, color = 'purple')
plt.axvline(chisquare.mean() + chisquare.std(), linestyle = 'dashed', linewidth = 2, color = 'black')
plt.axvline(chisquare.mean() - chisquare.std(), linestyle = 'dashed', linewidth = 2, color = 'black')
plt.show()
```


![png](output_5_0.png)



```python
exponential = np.random.exponential(50, 100)
plt.hist(exponential, bins = 20, color = 'green')
plt.title('Exponential Distribution')
plt.axvline(exponential.mean(), linestyle = 'solid', linewidth = 2, color = 'purple')
plt.axvline(exponential.mean() + exponential.std(), linestyle = 'dashed', linewidth = 2, color = 'black')
plt.axvline(exponential.mean() - exponential.std(), linestyle = 'dashed', linewidth = 2, color = 'black')
plt.show()

```


![png](output_6_0.png)



```python
#Evaluate whether the descriptive statistics provided useful information about the variable. 
    ##Descriptive statistics show where the population is grouped in regard to the mean and how much of the population falls
    ##outside of the standard deviation
#Can you identify any common characteristics of the distributions that could be usefully described 
#using the mean and/or standard deviation, versus the ones that could not?
    ##Normal, poisson, and gamma distributions appear fairly similar and you can infer the general shape of the population
    ##centered around the median.Chisquare, Binomial, and Exponential distributions are difficult to compare to the first 
    ##three distributions based on the unequal distribution of the data.
```


```python
#Generate two normally-distributed variables, one with a mean of 5 and standard deviation of 0.5,
#and the other with a mean of 10 and standard deviation of 1.Add them together to create a third variable.
#Graph the third variable using a histogram.
#Compute the mean and standard deviation and plot them as vertical lines on the histogram.
#Evaluate the descriptive statistics against the data.

dist1= np.random.normal (5, 0.5, 100)
dist2= np.random.normal (10, 1, 100)

dist3 = dist1 + dist2

plt.figure(figsize=(15,10))

plt.subplot(3, 1, 1)
plt.hist(dist1, bins = 20)
plt.axvline(dist1.mean(), linestyle = 'solid', color = 'black')
plt.axvline(dist1.mean() + dist1.std(), linestyle = 'dashed', color = 'green')
plt.axvline(dist1.mean() - dist1.std(), linestyle = 'dashed', color = 'green')
plt.xlim(2.5, 17.5)
plt.title ('Distribution 1')
plt.show()

plt.figure(figsize=(15,10))
plt.subplot(3, 1, 2)
plt.hist(dist2, bins = 20)
plt.axvline(dist2.mean(), linestyle = 'solid', color = 'black')
plt.axvline(dist2.mean() + dist2.std(), linestyle = 'dashed', color = 'green')
plt.axvline(dist2.mean() - dist2.std(), linestyle = 'dashed', color = 'green')
plt.title ('Distribution 2')
plt.xlim(2.5,17.5)
plt.show()

plt.figure(figsize=(15,10))
plt.subplot(3, 1, 3)
plt.hist(dist3, bins = 20)
plt.axvline(dist3.mean(), linestyle = 'solid', color = 'black')
plt.axvline(dist3.mean() + dist3.std(), linestyle = 'dashed', color = 'green')
plt.axvline(dist3.mean() - dist3.std(), linestyle = 'dashed', color = 'green')
plt.title('Distribution 3')
plt.xlim(2.5, 17.5)
plt.show()
```


![png](output_8_0.png)



![png](output_8_1.png)



![png](output_8_2.png)



```python
#the change in mean shifts the distribution to the right on the x axis as expected. A larger std increases the size 
#of the distribution seen in Distribution 2. The sum of the two original distributions (Distribution 3) reflects the sum:
#a larger mean and a larger standard deviation.
```
